<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="tag"></div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block" >
										<div class="snipcart-thumb">
											<a href="single.php?id=<?php echo $n ?>"><img title=" " alt=" " src="getImage.php?id=<?php echo $n ?>" /></a>
											<p><?php echo $row['nama_barang']; ?></p>
											<h4>Rp <?php echo $row['harga_barang']; ?> </h4>
										</div>
										
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>