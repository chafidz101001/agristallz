* admin :
  - login udah bisa nyambung ke database
  - ada yg eror gajelas contoh ("Message: Object of class CI_Loader could not be converted to string") itu gara" gw <?php echo $this->load->view('tampilan_menu')?> so sementara gw balikin dl ke semula 
  - belum ter secure soalnya eror mulu brusan dan gw ga ngerti alesanya knp liat aja di model_secure line 8 dan cek di application/controler/home.php gw jadiin comment dl sementara
  - belum bisa logout klo klik tombol logout kecuali dengan cara menuliskan -> http://localhost/Admin/admin/index.php/home/logout/ 
  - msh blm nyambung ke crud nya alias blm nyambungin kontenya

* crud :
 - masih ga ngerti kalo abis di edit suka engga ke save hasil edit nya (misal di crud barang)
 - klo engga di isi di form input maupun edit bukanya gagal tapi malah ttp ke save dan ga eror (fungsi cekForm() nya ga jalan) > baru di test di barang sih
  -> Barang:
     - di form input ato add datanya ada tanda (>)
     - fungsi add sama delete udah aman
  -> toko:
     - fungsi delete ga jalan samsek
     - fungsi edit nya ga munculin data yang sebelumnya
  -> user:
     - semua fungsi udah jalan tinggal hapus yang engga perlu mungkin kyk edit, ato add

* Resource:
 - https://youtu.be/KZX-DGYu_gU -> bahan crud

 #Admin + Konten
  - https://youtu.be/mo5WG_BVK5U -> ci 1 (login, secure)
  - https://www.youtube.com/watch?v=7rdceI4LEgQ -> ci 2 (konten+crud) >gw blm nonton videonya tapi ada di judulnya dr 2 sampai 4
  - https://www.youtube.com/watch?v=kbKKClNwrzU -> ci 3
  - https://www.youtube.com/watch?v=JXII0vcYA10 -> ci 4

 - https://stackoverflow.com/questions/44650858/call-to-undefined-function-set-flashdata-in-codeigniter
 - https://stackoverflow.com/questions/23842268/how-to-display-image-from-database-using-php
 - https://www.w3schools.com/tags/tag_select.asp


sorry parah malah lebih fokus ke crud nya dan msh banyak yang eror
sepenuhnya kodingan ini make framework CI (code igniter)
baca ada tulisan yang ga boleh di hapus !!