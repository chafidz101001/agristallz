<ul class="nav menu">
	<li class="active"><a href="index.html"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
	<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
		<em class="fa fa-navicon">&nbsp;</em> Database <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
		</a>
		<ul class="children collapse" id="sub-item-1">
			<li><a class="" href="<?php echo site_url('crud/toko/index') ?>">
				<span class="fa fa-arrow-right">&nbsp;</span> Toko
			</a></li>
			<li><a class="" href="#">
				<span class="fa fa-arrow-right">&nbsp;</span> Barang
			</a></li>
			<li><a class="" href="#">
				<span class="fa fa-arrow-right">&nbsp;</span> User
			</a></li>
		</ul>
	</li>
	<li><a href="login.html"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
</ul>