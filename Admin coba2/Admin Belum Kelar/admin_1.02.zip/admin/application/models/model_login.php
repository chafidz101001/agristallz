<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_login extends CI_model {

	public function getLogin($un,$pw)
	{
		$this->db->where('username_admin',$un);
		$this->db->where('password_admin',$pw);
		$query = $this->db->get('admin');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$sess = array('username_admin'	=> $row->username_admin,
							  'nama_admin'		=> $row->nama_admin,
							  'email_admin'		=> $row->email_admin);
				$this->session->set_userdata($sess);
				redirect('home');
			}
		}
		else
		{
			$this->session->set_flashdata('info','Sorry Your Username or Password is Wrong!!');
			redirect('login');
		}
	}
	
}
