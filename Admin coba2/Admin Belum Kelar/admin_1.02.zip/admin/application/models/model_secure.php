<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_secure extends CI_model {

	public function getSecure()
	{
		$username_admin->session->userdata('username_admin');
		if(empty($username_admin))
		{
			$this->session->sess_destroy();
			redirect('login');
		}
	}
}
