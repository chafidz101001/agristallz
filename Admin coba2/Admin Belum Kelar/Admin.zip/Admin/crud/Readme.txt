* admin :
  - login belum ngerti
  - msh blm nyambung ke crud nya tinggal nge href doang ko tapi gagal mulu
* crud :
 - masih ga ngerti kalo abis di edit suka engga ke save hasil edit nya (misal di crud barang)
 - klo engga di isi di form input maupun edit bukanya gagal tapi malah ttp ke save dan ga eror (fungsi cekForm() nya ga jalan) > baru di test di barang sih
  -> Barang:
     - di form input ato add datanya ada tanda (>)
     - fungsi add sama delete udah aman
  -> toko:
     - fungsi delete ga jalan samsek
     - fungsi edit nya ga munculin data yang sebelumnya
     - 
  -> user:
     - semua fungsi udah jalan tinggal hapus yang engga perlu mungkin kyk edit, ato add

* Resource:
 - https://youtu.be/KZX-DGYu_gU
 - https://youtu.be/mo5WG_BVK5U
 - https://stackoverflow.com/questions/23842268/how-to-display-image-from-database-using-php
 - https://www.w3schools.com/tags/tag_select.asp


sorry parah malah lebih fokus ke crud nya dan msh gagal