<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index(){
		$this->data['hasil'] = $this->model_crud->getUser('barang');
		$this->load->view('welcome_message', $this->data);
	}
	public function form_input(){
		$this->load->view('form-input');
	}
	public function insert(){
		$nmtk = $_POST['toko'];
		$nama = $_POST['name'];
		$price = $_POST['harga'];
		$kategori = $_POST['kategori'];
		$desc = $_POST['desk'];
		$frslvl = $_POST['lvl'];
		$gambar = $_POST['img'];
		$data = array('nama_toko' => $nmtk, 'nama_barang' => $nama, 'harga_barang' => $price, 'kategori' => $kategori, 'deskripsi' => $desc, 'fresh' => $frslvl, 'img' => $gambar);
		$add = $this->model_crud->addData('barang',$data);
		if($add > 0){
			echo redirect('welcome/index');
		}
		else {
			echo 'Input Failed';
		}
	}

	public function delete($id){
		$del = $this->model_crud->deleteData('barang',$id);
		if($del > 0){
			echo redirect('welcome/index');
		}
		else {
			echo 'Update Failed';
		}
	}

	public function form_edit($id){
		$this->data['dataEdit'] = $this->model_crud->dataEdit('barang',$id);
		$this->load->view('form-edit',$this->data);
	}

	public function update($id){
		$nmtk = $_POST['toko'];
		$nama = $_POST['name'];
		$price = $_POST['harga'];
		$kategori = $_POST['kategori'];
		$desc = $_POST['desk'];
		$frslvl = $_POST['lvl'];
		$gambar = $_POST['img'];
		$data = array('nama_toko' => $nmtk, 'nama_barang' => $nama, 'harga_barang' => $price, 'kategori' => $kategori, 'deskripsi' => $desc, 'fresh' => $frslvl, 'img' => $gambar);
		$edit = $this->model_crud->editData('barang',$data,$id);
		if($edit > 0){
			echo redirect('welcome/index');
		} else {
			echo 'Update Failed';
		}
	}
}
