<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Data Produk</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }
	font-family : "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: white;
		background-color: #006400;
		border-bottom: 1px solid #D0D0D0;
		font-size: 25px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	form{
		font-size : 20px;
		font-weight : bold;
	}

	input[type=text]{
		font-size: 17px;
		padding: 5px 15px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}

	.tombol{
		background: #00FF7F;
		color : white;
		border-top: 0;
		border-right: 0;
		border-left: 0;
		padding: 10px 20px;
		border-bottom : 5px solid #98FB98;
		text-decoration: none;
		font-family : sans-serif;
		font-size: 11pt;
	}

	input[type=submit]:hover{
			cursor :pointer;
			}
	input[type=submit]:active{
			cursor :#0044cc;
			}
	</style>
</head>
<body>
<script type="text/javascript">
function cekForm(){
	if(!$_POST['toko'].val())
		{
			alert('Maaf Nama Toko Tidak Boleh Kosong');
			$_POST['toko'].focus();
			return false;
		}
		if(!$_POST['name'].val())
		{
			alert('Maaf Nama Barang Tidak Boleh Kosong');
			$_POST['name'].focus();
			return false;
		}
		if(!$_POST['harga'].val())
		{
			alert('Maaf Harga Barang Tidak Boleh Kosong');
			$_POST['harga'].focus();
			return false;
		}
		if(!$_POST['kategori'].val()){
			alert('Maaf Kategori Tidak Boleh Kosong');
			$_POST['kategori'].focus();
			return false;
		}
		if(!$_POST['desk'].val()){
			alert('Maaf Deskripsi Barang Tidak Boleh Kosong');
			$_POST['desk'].focus();
			return false;
		}
		if(!$_POST['lvl'].val()){
			alert('Maaf Tingkat Kesegaran harus di pilih');
			$_POST['lvl'].focus();
			return false;
		}
		if(!$_POST['img'].val()){
			alert('Maaf Gambar Tidak Boleh Kosong');
			$_POST['img'].focus();
			return false;
		}
}
</script>
<div id="container">
	<h1>Form Input</h1>
	<div id="body">
		<form action="<?php echo site_url('welcome/insert')?>" method="POST">
			<table align=center>	
				<tr>	
					<td>Nama Toko</td>
					<td><input type="text" name="toko" /></td>
				</tr>
				<tr>
					<td>Nama Barang</td>
					<td><input type="text" name="name"/></td>
				</tr>
				<tr>	
					<td>Harga  Barang</td>
					<td><input type="text" name="harga" /></td>
				</tr>
				<tr>
					<td>Kategori</td>
					<td>	
						<select name='kategori'>
							<option value='Sayur dan Buah'> Sayur dan buah </option>
							<option value='Bumbu'> Bumbu </option>
							<option value='pokok'> Bahan Pokok </option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Deskripsi</td>
					<td><textarea rows=4 cols=30 name="desk"></textarea></td>
				</tr>
				<tr>
					<td>Fresh Level</td>
					<td>
						<select name='lvl'>
							<option value='1'> 1 </option>
							<option value='2'> 2 </option>
							<option value='3'> 3 </option>
							<option value='4'> 4 </option>
							<option value='5'> 5 </option>
							<option value='6'> 6 </option>
							<option value='7'> 7 </option>
							<option value='8'> 8 </option>
							<option value='9'> 9 </option>
							<option value='10'> 10 </option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Masukan Gambar</td>
					<td><input type="file" name="img"></td>>
				</tr>
				<tr>
					<td><input type="submit" onsubmit="return cekForm();" name="Simpan" value="Save" class="tombol"/></td>
					<td><a href="<?php echo site_url('welcome/index') ?>" class="tombol"> Back </a></td>
				</tr>
			</table>
		</form>
		
	</div>

	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>

</body>
</html>