<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index(){
		$this->data['hasil'] = $this->model_crud->getUser('toko');
		$this->load->view('welcome_message', $this->data);
	}
	public function form_input(){
		$this->load->view('form-input');
	}
	public function insert(){
		$nmtk = $_POST['toko'];
		$kontak = $_POST['kontak'];
		$alamat = $_POST['alamat'];
		$data = array('nama_toko' => $nmtk, 'kontak' => $kontak, 'alamat_toko' => $alamat);
		$add = $this->model_crud->addData('toko',$data);
		if($add > 0){
			echo redirect('welcome/index');
		}
		else {
			echo 'Update Failed';
		}
	}

	public function delete($nmtk){
		$delete = $this->model_crud->deleteData('toko',$nmtk);
		if($delete > 0){
			echo redirect('welcome/index');
		}
		else {
			echo 'Update Failed';
		}
	}

	public function form_edit($id){
		$this->data['dataEdit'] = $this->model_crud->dataEdit('toko',$id);
		$this->load->view('form-edit',$this->data);
	}

	public function update($id){
		$nmtk = $_POST['toko'];
		$kontak = $_POST['kontak'];
		$alamat = $_POST['alamat'];
		$data = array('nama_toko' => $nmtk, 'kontak' => $kontak, 'alamat_toko' => $alamat);
		$edit = $this->model_crud->editData('toko',$data,$id);
		if($edit > 0){
			echo redirect('welcome/index');
		} else {
			echo 'Update Failed';
		}
	}
}
